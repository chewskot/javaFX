package javaapplication2;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class FXMLController implements Initializable {

    @FXML
    private Button btnKonec;
    @FXML
    private Button btnVymaz;
    @FXML
    private CheckBox chVypln;
    @FXML
    private ColorPicker barva;
    @FXML
    private Pane Panel;

    private List<Double> points = new ArrayList<>();
    private List<Line> lines = new ArrayList<>();

    private List<Polygon> polygons = new ArrayList<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Panel.setStyle("-fx-background-color: rgb(255,255,192)");
        barva.setValue(Color.RED);
    }

    @FXML
    private void onKonec(javafx.event.ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void onVymaz(javafx.event.ActionEvent event) {
        Panel.getChildren().removeAll(lines); // Odstraní všechny čáry z Panelu
        lines.clear(); // Vyprázdní seznam lines
        points.clear();

        // Odstraníme všechny polygony z Panelu a vyprázdníme seznam polygonů
        Panel.getChildren().removeAll(polygons);
        polygons.clear();
    }

    @FXML
    private void onVypln(javafx.event.ActionEvent event) {
    }

    @FXML
    private void onPress(MouseEvent event) {
        double x = event.getX();
        double y = event.getY();

        if (points.isEmpty()) {
            points.add(x);
            points.add(y);
        } else {
            double lastX = points.get(points.size() - 2);
            double lastY = points.get(points.size() - 1);
            createLine(lastX, lastY, x, y);
            points.add(x);
            points.add(y);
        }

        if (event.isControlDown()) {
            createPolygon();
        }
    }

    @FXML
    private void onRelease(MouseEvent event) {

        if (event.isControlDown() && points.size() > 2) {
            createPolygon();
        }
    }

    @FXML
    private void createLine(double startX, double startY, double endX, double endY) {
        Line line = new Line(startX, startY, endX, endY);
        line.setStroke(Color.BLACK); // Nastavíme barvu čáry na černou
        line.setStrokeWidth(2.0);

        // Nastavíme čáru jako pruhovanou
        double dashWidth = 5.0; // Šířka pruhů
        double gapWidth = 5.0; // Šířka mezer mezi pruhy
        line.getStrokeDashArray().addAll(dashWidth, gapWidth);

        lines.add(line);
        Panel.getChildren().add(line);
    }

    @FXML
    private void createPolygon() {
        Polygon polygon = new Polygon();
        polygon.getPoints().addAll(points);

        if (chVypln.isSelected()) {
            polygon.setFill(barva.getValue());
        } else {
            polygon.setFill(Color.TRANSPARENT); // Nastavíme průhlednou výplň
        }

        List<Line> polygonLines = createLinesFromPolygon(polygon);
        lines.addAll(polygonLines);

        // Přidáme polygon do seznamu polygonů
        polygons.add(polygon);

        Panel.getChildren().addAll(polygon);
        Panel.getChildren().addAll(polygonLines);
        points.clear();
    }

    private List<Line> createLinesFromPolygon(Polygon polygon) {
        List<Line> polygonLines = new ArrayList<>();
        List<Double> points = polygon.getPoints();
        int numPoints = points.size();

        for (int i = 0; i < numPoints; i += 2) {
            double startX = points.get(i);
            double startY = points.get(i + 1);
            double endX = points.get((i + 2) % numPoints);
            double endY = points.get((i + 3) % numPoints);
            Line line = new Line(startX, startY, endX, endY);
            line.setStroke(chVypln.isSelected() ? barva.getValue() : Color.TRANSPARENT);
            line.setStrokeWidth(2.0);
            polygonLines.add(line);
        }

        return polygonLines;
    }
}
