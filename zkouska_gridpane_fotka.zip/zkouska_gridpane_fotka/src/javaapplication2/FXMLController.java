/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javaapplication2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * FXML Controller class
 *
 * @author mojan
 */
public class FXMLController implements Initializable {

    @FXML
    private Button btnUpload;
    @FXML
    private Spinner<Integer> radkySpin;
    @FXML
    private Spinner<Integer> sloupceSpin;
    @FXML
    private AnchorPane anchorP;
    @FXML
    private GridPane gridP;
    
    private SpinnerValueFactory<Integer> radkyFactory  = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10,3) {
    };
     private SpinnerValueFactory<Integer> sloupceFactory  = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10,4) {
    };
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        radkySpin.setValueFactory(radkyFactory);
        sloupceSpin.setValueFactory(sloupceFactory);
        radkySpin.valueProperty().addListener((observable, oldValue, newValue) -> {
        updateGridRows(newValue);
    });

    sloupceSpin.valueProperty().addListener((observable, oldValue, newValue) -> {
        updateGridColumns(newValue);
    });
    
    
    for (Node node : gridP.getChildren()) {
        if (node instanceof Rectangle) {
            Rectangle cell = (Rectangle) node;
            cell.setOnMouseClicked(this::cellClick);
        }
    }
    }    
    private void updateGridRows(int newValue) {
    gridP.getRowConstraints().clear(); // Vymažte stávající řádky

    for (int i = 0; i < newValue; i++) {
        RowConstraints row = new RowConstraints(anchorP.getHeight()/newValue); // Změňte výšku podle potřeby
        gridP.getRowConstraints().add(row);
    }
}

private void updateGridColumns(int newValue) {
    gridP.getColumnConstraints().clear(); // Vymažte stávající sloupce

    for (int i = 0; i < newValue; i++) {
        ColumnConstraints col = new ColumnConstraints(anchorP.getWidth()/newValue); // Změňte šířku podle potřeby
        gridP.getColumnConstraints().add(col);
    }
}

    @FXML
    private void onUpload(ActionEvent event) {
    }
private void cellClick(MouseEvent event) {
    // Metoda, která bude volána při kliknutí na buňku
    Rectangle cell = (Rectangle) event.getSource();
    cell.setFill(Color.BLACK); // Změna barvy buňky na černou
}
    
}
