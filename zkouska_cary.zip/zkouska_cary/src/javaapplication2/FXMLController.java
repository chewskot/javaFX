/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javaapplication2;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TouchEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;

/**
 * FXML Controller class
 *
 * @author mojan
 */
public class FXMLController implements Initializable {

    @FXML
    private Pane plocha;
    @FXML
    private HBox hb;
    @FXML
    private Label pocet;
    @FXML
    private ColorPicker barva;
    @FXML
    private Slider tlouska;
    @FXML
    private ChoiceBox<String> styl;
    double startX;
    double startY;
    double endX;
    double endY;
    int cetnost = 0;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Ellipse ellipse = new Ellipse();
        plocha.getChildren().add(ellipse);
        barva.setValue(Color.RED);
        ellipse.setFill(Color.BLUE);
        Stop[] stops = new Stop[]{new Stop(0, Color.WHITE), new Stop(1, Color.BLUE)};
        RadialGradient gradient = new RadialGradient(0, 0, 0.5, 0.5, 0.5, true, CycleMethod.NO_CYCLE, stops);
        ellipse.setFill(gradient);
        styl.getItems().addAll("Plná", "Čárkovaná", "Čerchovaná");
        styl.setValue("Plná"); // Nastavit výchozí hodnotu

        // Nastavení vlastnosti Ellipse
        ellipse.centerXProperty().bind(plocha.widthProperty().divide(2)); // Střed X
        ellipse.centerYProperty().bind(plocha.heightProperty().divide(2)); // Střed Y

        // Nastavení šířky a výšky elipsy na polovinu minimálního rozměru páně (výška nebo šířka)
        double polomerX = plocha.getWidth() / 2;
        double polomerY = plocha.getHeight() / 2;
        ellipse.setRadiusX(polomerX);
        ellipse.setRadiusY(polomerY);

        // Reagovat na změny velikosti Pane
        plocha.widthProperty().addListener((obs, oldVal, newVal) -> {
            double newPolomerX = newVal.doubleValue() / 2;
            ellipse.setRadiusX(newPolomerX);
        });

        plocha.heightProperty().addListener((obs, oldVal, newVal) -> {
            double newPolomerY = newVal.doubleValue() / 2;
            ellipse.setRadiusY(newPolomerY);
        });
    }

    @FXML
    private void onPress(MouseEvent event) {
        startX = event.getX();
        startY = event.getY();
    }

    @FXML
    private void onRelease(MouseEvent event) {
        endX = event.getX();
        endY = event.getY();
        createLine();
    }

    private void createLine() {
        Line line = new Line(startX, startY, endX, endY);

        if (styl.getValue() == "Čárkovaná") {
            // Nastavit čárkovaný styl
            line.getStrokeDashArray().setAll(5.0 * tlouska.getValue(), 5.0 * tlouska.getValue()); // Čára relativní k tloušťce

        } else if (styl.getValue() == "Čerchovaná") {
            // Nastavit čerchovaný styl
            line.getStrokeDashArray().setAll(5.0 * tlouska.getValue(), 5.0 * tlouska.getValue(), tlouska.getValue(), 5.0 * tlouska.getValue()); // Čára relativní k tloušťce

        }
        line.setStroke(barva.getValue());
        line.setStrokeWidth(tlouska.getValue());
        plocha.getChildren().add(line);
        cetnost++;
        pocet.setText(String.valueOf(cetnost));
    }

}
