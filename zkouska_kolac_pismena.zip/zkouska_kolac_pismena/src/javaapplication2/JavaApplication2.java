/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import static javafx.scene.control.SelectionMode.MULTIPLE;
import javafx.scene.control.SelectionModel;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author mojan
 */
public class JavaApplication2 extends Application {

    private PieChart pieChart;
    private TextField inputField;
    private ListView<String> wordListView;
    private ObservableList<String> wordList;

    @Override
    public void start(Stage primaryStage) {
        pieChart = new PieChart();
        primaryStage.setResizable(false);
        inputField = new TextField();
        Button addButton = new Button("Přidat slovo");
        addButton.setOnAction(this::handleAddButton);

        Button removeAllButton = new Button("Odstranit vše");
        removeAllButton.setOnAction(this::handleRemoveAllButton);

        Button removeSelectedButton = new Button("Odstranit vybrané");
        removeSelectedButton.setOnAction(this::handleRemoveSelectedButton);

        wordList = FXCollections.observableArrayList();
        wordListView = new ListView<>(wordList);
        wordListView.setPrefSize(200, 300);
        wordListView.getSelectionModel().setSelectionMode(MULTIPLE);

        VBox leftBox = new VBox(10);
        leftBox.setPadding(new Insets(10));
        leftBox.setAlignment(Pos.CENTER);
        leftBox.getChildren().addAll(inputField, addButton, removeAllButton, removeSelectedButton, wordListView);

        HBox root = new HBox(10);
        root.setPadding(new Insets(10));
        root.setAlignment(Pos.CENTER);
        root.getChildren().addAll(leftBox, pieChart);

        Scene scene = new Scene(root, 600, 400);
        primaryStage.setTitle("Koláčový graf");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private ObservableList<PieChart.Data> createPieChartData(ObservableList<String> wordList) {
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();

        int[] letterCount = new int[26];
        int totalCount = 0;

        // Počítání četností jednotlivých písmen
        for (String word : wordList) {
            for (char c : word.toCharArray()) {
                if (Character.isLetter(c)) {
                    letterCount[c - 'A']++;
                    totalCount++;
                }
            }
        }

        // Vytvoření dat pro koláčový graf
        for (int i = 0; i < 26; i++) {
            char letter = (char) ('A' + i);
            int count = letterCount[i];
            pieChartData.add(new PieChart.Data(String.valueOf(letter), count));
        }

        return pieChartData;
    }

    private void handleAddButton(ActionEvent event) {
        String word = inputField.getText().toUpperCase();
        wordList.add(word);
        updatePieChart();
    }

    private void handleRemoveAllButton(ActionEvent event) {
        wordList.clear();
        updatePieChart();
    }

    private void handleRemoveSelectedButton(ActionEvent event) {
        ObservableList<String> selectedItems = wordListView.getSelectionModel().getSelectedItems();
        wordList.removeAll(selectedItems);
        updatePieChart();
    }

    private void updatePieChart() {
        ObservableList<PieChart.Data> pieChartData = createPieChartData(wordList);
        pieChart.setData(pieChartData);
        setChartLabels(pieChartData);
    }

    

    private void setChartLabels(ObservableList<PieChart.Data> pieChartData) {
        for (PieChart.Data data : pieChartData) {
            data.setName(data.getName() + ": " + (int) data.getPieValue());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
