/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javaapplication2;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TouchEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;

/**
 * FXML Controller class
 *
 * @author mojan
 */
public class FXMLController implements Initializable {

    @FXML
    private Button btnKonec;
    @FXML
    private Button btnVymaz;
    @FXML
    private Pane plocha;
    double zacX = 0;
    double zacY = 0;
    double konX = 0;
    double konY = 0;
    List<Circle> kruhy = new ArrayList();
    int pocet = 0;
    @FXML
    private HBox hb;
    @FXML
    private Label lbPocet;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        Stop[] stops = new Stop[]{
            new Stop(0, Color.WHITE),
            new Stop(1, Color.RED)
        };

        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        plocha.setBackground(new javafx.scene.layout.Background(new javafx.scene.layout.BackgroundFill(gradient, null, null)));

    }

    @FXML
    private void onKonec(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void onVymaz(ActionEvent event) {
        kruhy.clear();
        plocha.getChildren().clear();
        pocet=0;
        lbPocet.setText("Pocet kruhu: " + pocet);
    }

    @FXML
    private void onRelease(MouseEvent event) {
        konX = event.getX();
        konY = event.getY();
        double radius = Math.max(Math.abs(konX - zacX), Math.abs(konY - zacY));
        Circle kruh = new Circle(zacX, zacY, radius, Color.BLUE);
        kruh.setOpacity(0.5);
        kruhy.add(kruh);
        pocet++;
        lbPocet.setText("Pocet kruhu: " + pocet);
        plocha.getChildren().add(kruh);

        hb.toFront();

        for (Circle existingCircle : kruhy) {
            if (kruh != existingCircle && kruh.intersects(existingCircle.getBoundsInLocal())) {
                kruh.setFill(Color.RED);
                existingCircle.setFill(Color.RED);
                kruh.setOpacity(1);
                existingCircle.setOpacity(1);
            }
        }

    }

    @FXML
    private void onPress(MouseEvent event) {
        zacX = event.getX();
        zacY = event.getY();
    }

}
