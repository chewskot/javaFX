package javaapplication2;

import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javaapplication2.Auto.Znacka;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class FXMLController implements Initializable {

    @FXML
    private ListView<Auto> lv;
    @FXML
    private Button btnOdeber;
    @FXML
    private Button btnPridej;
    private InputDController inputController;
    List<Auto> auta = new ArrayList<Auto>();
    @FXML
    private BarChart<String, Number> graf;
    CategoryAxis xAxis = new CategoryAxis();
    NumberAxis yAxis = new NumberAxis();

    // Mapa pro uchování počtu aut podle značky
    Map<String, Integer> pocetZnacek = new HashMap<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Nastavení popisků os a jejich přidání do grafu
        xAxis.setLabel("Značka auta");
        yAxis.setLabel("Počet aut");
        graf.setTitle("Počet aut podle značky");
        graf.setLegendVisible(false);
        graf.setCategoryGap(30);

        // Nastavení os X a Y pro graf
        graf.setAnimated(false);
        graf.setHorizontalGridLinesVisible(true);
        graf.setVerticalGridLinesVisible(true);

        graf.setCategoryGap(30);

        graf.setBarGap(3);
        graf.setCategoryGap(20);

        graf.setLegendVisible(false);
        //yAxis.setAutoRanging(false);
        

    }

    @FXML
    private void onOdeber(ActionEvent event) {
        int od = lv.getSelectionModel().getSelectedIndex();
        if (od >= 0) {
            Auto odebraneAuto = lv.getItems().remove(od);
            auta.remove(odebraneAuto);
            update();
        }
    }

    @FXML
    private void onPridej(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("InputD.fxml"));
            Parent root = loader.load();
            inputController = loader.getController();

            // Získání dat z InputD.fxml
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.showAndWait();
            if (!inputController.ne) {
                // Zavolání metody ve třídě InputDController
                if (inputController != null) {
                    String majitel = inputController.getTxtMajitel().getText();
                    String spz = inputController.getTxtSpz().getText();
                    int rok = Integer.parseInt(inputController.getTxtRok().getText());
                    Znacka znacka = inputController.getCombo();
                    Auto auto = new Auto(majitel, rok, spz, znacka);
                    lv.getItems().add(auto);
                    auta.add(auto);

                    // Aktualizace počtu aut podle značky
                    pocetZnacek.put(znacka.name(), pocetZnacek.getOrDefault(znacka.name(), 0) + 1);

                    update();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void update() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();

        for (String znacka : pocetZnacek.keySet()) {
            int pocet = pocetZnacek.get(znacka);
            series.getData().add(new XYChart.Data<>(znacka, pocet));
        }

        graf.getData().clear();
        graf.getData().add(series);
    }
}
