/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javaapplication2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author mojan
 */

public class InputDController implements Initializable {

    public Auto.Znacka getCombo() {
        return combo.getValue();
    }

    public Button getBtnOk() {
        return btnOk;
    }

    public Button getBtnCancel() {
        return btnCancel;
    }

    public TextField getTxtMajitel() {
        return txtMajitel;
    }

    public TextField getTxtSpz() {
        return txtSpz;
    }

    public TextField getTxtRok() {
        return txtRok;
    }

    @FXML
    private ComboBox<Auto.Znacka> combo;
    @FXML
    private Button btnOk;
    @FXML
    private Button btnCancel;
    @FXML
    private TextField txtMajitel;
    @FXML
    private TextField txtSpz;
    @FXML
    private TextField txtRok;
    public boolean ne = false;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        combo.getItems().addAll(Auto.Znacka.values());
    }

    @FXML
    private void onOk(ActionEvent event) {
        String majitel = txtMajitel.getText();
        String spz = txtSpz.getText();
        String rok = txtRok.getText();
        Auto.Znacka znacka = combo.getValue();

        // Validate the input
        if (majitel.isEmpty() || spz.isEmpty() || rok.isEmpty() || znacka == null) {
            // Display an error message
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText(null);
            alert.setContentText("Please fill in all fields.");
            alert.showAndWait();
            return;
        }
        ne=false;
        // Close the window
        Stage stage = (Stage) btnOk.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void onCancel(ActionEvent event) {
        closeWindow();

    }

    public void closeWindow() {
        Stage stage = (Stage) btnCancel.getScene().getWindow();
        stage.close();
        ne=true;
    }
}
