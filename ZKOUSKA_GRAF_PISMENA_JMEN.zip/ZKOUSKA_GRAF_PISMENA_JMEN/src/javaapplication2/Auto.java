/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

/**
 *
 * @author mojan
 */
public class Auto {

    String majitel;
    int rok;
    String SPZ;

    enum Znacka {
        SKODA, SEAT, RENAULT, MAZDA, JINA
    }
    Znacka znacka;

    @Override
    public String toString() {
        return "Auto{" + "majitel=" + majitel + ", rok=" + rok + ", SPZ=" + SPZ + ", znacka=" + znacka + '}';
    }
    
    public Auto(String majitel, int rok, String SPZ, Znacka znacka) {
        this.majitel = majitel;
        this.rok = rok;
        this.SPZ = SPZ;
        this.znacka = znacka;
    }

    public String getMajitel() {
        return majitel;
    }

    public void setMajitel(String majitel) {
        this.majitel = majitel;
    }

    public int getRok() {
        return rok;
    }

    public void setRok(int rok) {
        this.rok = rok;
    }

    public String getSPZ() {
        return SPZ;
    }

    public void setSPZ(String SPZ) {
        this.SPZ = SPZ;
    }

    public Znacka getZnacka() {
        return znacka;
    }

    public void setZnacka(Znacka znacka) {
        this.znacka = znacka;
    }
    

}
